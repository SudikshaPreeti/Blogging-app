import express from "express";
import { 
    subscribeToNewsletter, 
    unsubscribeFromNewsletter, 
    getAllSubscribers, 
    getSubscriptionStats 
} from "../controllers/newsletter.controller.js";
import { isAuthenticated } from "../middleware/isAuthenticated.js";

const router = express.Router();

// Public routes
router.post("/subscribe", subscribeToNewsletter);
router.post("/unsubscribe", unsubscribeFromNewsletter);

// Admin routes (protected)
router.get("/subscribers", isAuthenticated, getAllSubscribers);
router.get("/stats", isAuthenticated, getSubscriptionStats);

export default router; 