import express from "express";
import {
    getAllUsers,
    getUserById,
    updateUserRole,
    toggleUserBlock,
    deleteUser,
    getAllBlogsAdmin,
    updateBlogStatus,
    deleteBlogAdmin,
    getDashboardStats
} from "../controllers/admin.controller.js";
import { isAuthenticated } from "../middleware/isAuthenticated.js";

const router = express.Router();

// Admin middleware - check if user is admin
const isAdmin = async (req, res, next) => {
    try {
        // Get user from database using req.id
        const User = (await import("../models/user.model.js")).User;
        const user = await User.findById(req.id);
        
        if (user && user.role === 'admin') {
            req.user = user; // Set user object for later use
            next();
        } else {
            return res.status(403).json({
                success: false,
                message: "Access denied. Admin privileges required."
            });
        }
    } catch (error) {
        console.error('Admin middleware error:', error);
        return res.status(500).json({
            success: false,
            message: "Error checking admin privileges"
        });
    }
};

// Dashboard stats
router.get("/dashboard-stats", isAuthenticated, isAdmin, getDashboardStats);

// User management routes
router.get("/users", isAuthenticated, isAdmin, getAllUsers);
router.get("/users/:userId", isAuthenticated, isAdmin, getUserById);
router.put("/users/:userId/role", isAuthenticated, isAdmin, updateUserRole);
router.put("/users/:userId/block", isAuthenticated, isAdmin, toggleUserBlock);
router.delete("/users/:userId", isAuthenticated, isAdmin, deleteUser);

// Blog management routes
router.get("/blogs", isAuthenticated, isAdmin, getAllBlogsAdmin);
router.put("/blogs/:blogId/status", isAuthenticated, isAdmin, updateBlogStatus);
router.delete("/blogs/:blogId", isAuthenticated, isAdmin, deleteBlogAdmin);

export default router; 