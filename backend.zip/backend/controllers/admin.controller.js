import { User } from "../models/user.model.js";
import { Blog } from "../models/blog.model.js";
import Comment from "../models/comment.model.js";
import { Newsletter } from "../models/newsletter.model.js";

// Get all users (admin only)
export const getAllUsers = async (req, res) => {
    try {
        console.log('Getting all users...');
        const users = await User.find({}).select('-password').sort({ createdAt: -1 });
        
        console.log('Found users:', users.length);
        
        res.status(200).json({
            success: true,
            users,
            totalUsers: users.length
        });
    } catch (error) {
        console.log('Error in getAllUsers:', error);
        res.status(500).json({
            success: false,
            message: "Failed to fetch users"
        });
    }
};

// Get user by ID
export const getUserById = async (req, res) => {
    try {
        const { userId } = req.params;
        const user = await User.findById(userId).select('-password');
        
        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }
        
        res.status(200).json({
            success: true,
            user
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({
            success: false,
            message: "Failed to fetch user"
        });
    }
};

// Update user role (make admin/remove admin)
export const updateUserRole = async (req, res) => {
    try {
        const { userId } = req.params;
        const { role } = req.body;
        
        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }
        
        user.role = role;
        await user.save();
        
        res.status(200).json({
            success: true,
            message: `User role updated to ${role}`,
            user
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({
            success: false,
            message: "Failed to update user role"
        });
    }
};

// Block/Unblock user
export const toggleUserBlock = async (req, res) => {
    try {
        const { userId } = req.params;
        
        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }
        
        // Toggle the blocked status
        user.isBlocked = !user.isBlocked;
        await user.save();
        
        const action = user.isBlocked ? "blocked" : "unblocked";
        
        res.status(200).json({
            success: true,
            message: `User ${action} successfully`,
            user: {
                _id: user._id,
                firstName: user.firstName,
                lastName: user.lastName,
                email: user.email,
                role: user.role,
                isBlocked: user.isBlocked
            }
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({
            success: false,
            message: "Failed to update user block status"
        });
    }
};

// Delete user
export const deleteUser = async (req, res) => {
    try {
        const { userId } = req.params;
        
        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }
        
        // Delete user's blogs
        await Blog.deleteMany({ author: userId });
        
        // Delete user's comments
        await Comment.deleteMany({ userId: userId });
        
        // Delete user
        await User.findByIdAndDelete(userId);
        
        res.status(200).json({
            success: true,
            message: "User deleted successfully"
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({
            success: false,
            message: "Failed to delete user"
        });
    }
};

// Get all blogs (admin view)
export const getAllBlogsAdmin = async (req, res) => {
    try {
        console.log('Getting all blogs...');
        const blogs = await Blog.find({})
            .populate({
                path: 'author',
                select: 'firstName lastName email photoUrl'
            })
            .populate({
                path: 'comments',
                populate: {
                    path: 'userId',
                    select: 'firstName lastName'
                }
            })
            .sort({ createdAt: -1 });
        
        console.log('Found blogs:', blogs.length);
        
        res.status(200).json({
            success: true,
            blogs,
            totalBlogs: blogs.length
        });
    } catch (error) {
        console.log('Error in getAllBlogsAdmin:', error);
        res.status(500).json({
            success: false,
            message: "Failed to fetch blogs"
        });
    }
};

// Update blog status (publish/unpublish)
export const updateBlogStatus = async (req, res) => {
    try {
        const { blogId } = req.params;
        const { isPublished } = req.body;
        
        const blog = await Blog.findById(blogId);
        if (!blog) {
            return res.status(404).json({
                success: false,
                message: "Blog not found"
            });
        }
        
        blog.isPublished = isPublished;
        await blog.save();
        
        const statusMessage = isPublished ? "published" : "unpublished";
        
        res.status(200).json({
            success: true,
            message: `Blog ${statusMessage} successfully`,
            blog
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({
            success: false,
            message: "Failed to update blog status"
        });
    }
};

// Delete blog (admin)
export const deleteBlogAdmin = async (req, res) => {
    try {
        const { blogId } = req.params;
        
        const blog = await Blog.findById(blogId);
        if (!blog) {
            return res.status(404).json({
                success: false,
                message: "Blog not found"
            });
        }
        
        // Delete blog
        await Blog.findByIdAndDelete(blogId);
        
        // Delete related comments
        await Comment.deleteMany({ postId: blogId });
        
        res.status(200).json({
            success: true,
            message: "Blog deleted successfully"
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({
            success: false,
            message: "Failed to delete blog"
        });
    }
};

// Get dashboard stats
export const getDashboardStats = async (req, res) => {
    try {
        console.log('Getting dashboard stats...');
        const totalUsers = await User.countDocuments();
        const totalBlogs = await Blog.countDocuments();
        const publishedBlogs = await Blog.countDocuments({ isPublished: true });
        const totalComments = await Comment.countDocuments();
        const totalSubscribers = await Newsletter.countDocuments({ isSubscribed: true });
        
        // Get recent users (last 7 days)
        const sevenDaysAgo = new Date();
        sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
        const recentUsers = await User.countDocuments({ createdAt: { $gte: sevenDaysAgo } });
        
        // Get recent blogs (last 7 days)
        const recentBlogs = await Blog.countDocuments({ createdAt: { $gte: sevenDaysAgo } });
        
        // Get recent subscribers (last 7 days)
        const recentSubscribers = await Newsletter.countDocuments({
            isSubscribed: true,
            subscribedAt: { $gte: sevenDaysAgo }
        });
        
        const stats = {
            totalUsers,
            totalBlogs,
            publishedBlogs,
            totalComments,
            totalSubscribers,
            recentUsers,
            recentBlogs,
            recentSubscribers
        };
        
        console.log('Dashboard stats:', stats);
        
        res.status(200).json({
            success: true,
            stats
        });
    } catch (error) {
        console.log('Error in getDashboardStats:', error);
        res.status(500).json({
            success: false,
            message: "Failed to fetch dashboard stats"
        });
    }
}; 