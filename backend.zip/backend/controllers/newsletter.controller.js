import { Newsletter } from "../models/newsletter.model.js";

// Subscribe to newsletter
export const subscribeToNewsletter = async (req, res) => {
    try {
        const { email } = req.body;

        if (!email) {
            return res.status(400).json({
                success: false,
                message: "Email is required"
            });
        }

        // Validate email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            return res.status(400).json({
                success: false,
                message: "Please enter a valid email address"
            });
        }

        // Check if already subscribed
        const existingSubscriber = await Newsletter.findOne({ email: email.toLowerCase() });
        
        if (existingSubscriber) {
            if (existingSubscriber.isSubscribed) {
                return res.status(400).json({
                    success: false,
                    message: "You are already subscribed to our newsletter"
                });
            } else {
                // Resubscribe
                existingSubscriber.isSubscribed = true;
                existingSubscriber.subscribedAt = new Date();
                await existingSubscriber.save();
                
                return res.status(200).json({
                    success: true,
                    message: "Successfully resubscribed to newsletter"
                });
            }
        }

        // Create new subscription
        const newSubscriber = await Newsletter.create({
            email: email.toLowerCase()
        });

        res.status(201).json({
            success: true,
            message: "Successfully subscribed to newsletter",
            subscriber: {
                email: newSubscriber.email,
                subscribedAt: newSubscriber.subscribedAt
            }
        });

    } catch (error) {
        console.log('Newsletter subscription error:', error);
        res.status(500).json({
            success: false,
            message: "Failed to subscribe to newsletter"
        });
    }
};

// Unsubscribe from newsletter
export const unsubscribeFromNewsletter = async (req, res) => {
    try {
        const { email } = req.body;

        if (!email) {
            return res.status(400).json({
                success: false,
                message: "Email is required"
            });
        }

        const subscriber = await Newsletter.findOne({ email: email.toLowerCase() });
        
        if (!subscriber) {
            return res.status(404).json({
                success: false,
                message: "Email not found in our subscribers list"
            });
        }

        if (!subscriber.isSubscribed) {
            return res.status(400).json({
                success: false,
                message: "You are already unsubscribed from our newsletter"
            });
        }

        subscriber.isSubscribed = false;
        await subscriber.save();

        res.status(200).json({
            success: true,
            message: "Successfully unsubscribed from newsletter"
        });

    } catch (error) {
        console.log('Newsletter unsubscription error:', error);
        res.status(500).json({
            success: false,
            message: "Failed to unsubscribe from newsletter"
        });
    }
};

// Get all subscribers (admin only)
export const getAllSubscribers = async (req, res) => {
    try {
        const subscribers = await Newsletter.find({ isSubscribed: true })
            .sort({ subscribedAt: -1 });

        res.status(200).json({
            success: true,
            subscribers,
            totalSubscribers: subscribers.length
        });

    } catch (error) {
        console.log('Get subscribers error:', error);
        res.status(500).json({
            success: false,
            message: "Failed to fetch subscribers"
        });
    }
};

// Get subscription stats (admin only)
export const getSubscriptionStats = async (req, res) => {
    try {
        const totalSubscribers = await Newsletter.countDocuments({ isSubscribed: true });
        const totalUnsubscribed = await Newsletter.countDocuments({ isSubscribed: false });
        
        // Get recent subscribers (last 7 days)
        const sevenDaysAgo = new Date();
        sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
        const recentSubscribers = await Newsletter.countDocuments({
            isSubscribed: true,
            subscribedAt: { $gte: sevenDaysAgo }
        });

        const stats = {
            totalSubscribers,
            totalUnsubscribed,
            recentSubscribers
        };

        res.status(200).json({
            success: true,
            stats
        });

    } catch (error) {
        console.log('Get subscription stats error:', error);
        res.status(500).json({
            success: false,
            message: "Failed to fetch subscription stats"
        });
    }
}; 