import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { toast } from 'sonner';
import axios from 'axios';
import { Users, FileText, MessageSquare, TrendingUp, Trash2, Edit, Eye, UserCheck, UserX, Shield, ShieldCheck } from 'lucide-react';

const AdminDashboard = () => {
    const [stats, setStats] = useState({});
    const [users, setUsers] = useState([]);
    const [blogs, setBlogs] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedUser, setSelectedUser] = useState(null);
    const [selectedBlog, setSelectedBlog] = useState(null);

    // Fetch dashboard stats
    const fetchStats = async () => {
        try {
            console.log('Fetching dashboard stats...');
            const response = await axios.get('https://blogging-h2hl.onrender.com/api/v1/admin/dashboard-stats', {
                withCredentials: true
            });
            console.log('Stats response:', response.data);
            if (response.data.success) {
                setStats(response.data.stats);
            }
        } catch (error) {
            console.error('Error fetching stats:', error);
            if (error.response && error.response.data && error.response.data.message) {
                toast.error(error.response.data.message);
            } else {
                toast.error('Failed to fetch dashboard stats');
            }
        }
    };

    // Fetch all users
    const fetchUsers = async () => {
        try {
            console.log('Fetching users...');
            const response = await axios.get('https://blogging-h2hl.onrender.com/api/v1/admin/users', {
                withCredentials: true
            });
            console.log('Users response:', response.data);
            if (response.data.success) {
                setUsers(response.data.users);
            }
        } catch (error) {
            console.error('Error fetching users:', error);
            if (error.response && error.response.data && error.response.data.message) {
                toast.error(error.response.data.message);
            } else {
                toast.error('Failed to fetch users');
            }
        }
    };

    // Fetch all blogs
    const fetchBlogs = async () => {
        try {
            console.log('Fetching blogs...');
            const response = await axios.get('https://blogging-h2hl.onrender.com/api/v1/admin/blogs', {
                withCredentials: true
            });
            console.log('Blogs response:', response.data);
            if (response.data.success) {
                setBlogs(response.data.blogs);
            }
        } catch (error) {
            console.error('Error fetching blogs:', error);
            if (error.response && error.response.data && error.response.data.message) {
                toast.error(error.response.data.message);
            } else {
                toast.error('Failed to fetch blogs');
            }
        }
    };

    // Update user role
    const updateUserRole = async (userId, newRole) => {
        try {
            const response = await axios.put(`https://blogging-h2hl.onrender.com/api/v1/admin/users/${userId}/role`, {
                role: newRole
            }, {
                withCredentials: true
            });
            if (response.data.success) {
                toast.success(response.data.message);
                fetchUsers(); // Refresh users list
            }
        } catch (error) {
            console.error('Error updating user role:', error);
            toast.error('Failed to update user role');
        }
    };

    // Toggle user block status
    const toggleUserBlock = async (userId) => {
        try {
            const response = await axios.put(`https://blogging-h2hl.onrender.com/api/v1/admin/users/${userId}/block`, {}, {
                withCredentials: true
            });
            if (response.data.success) {
                toast.success(response.data.message);
                fetchUsers(); // Refresh users list
            }
        } catch (error) {
            console.error('Error toggling user block status:', error);
            toast.error('Failed to update user block status');
        }
    };

    // Delete user
    const deleteUser = async (userId) => {
        if (!confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
            return;
        }
        try {
            const response = await axios.delete(`https://blogging-h2hl.onrender.com/api/v1/admin/users/${userId}`, {
                withCredentials: true
            });
            if (response.data.success) {
                toast.success('User deleted successfully');
                fetchUsers(); // Refresh users list
            }
        } catch (error) {
            console.error('Error deleting user:', error);
            toast.error('Failed to delete user');
        }
    };

    // Update blog status
    const updateBlogStatus = async (blogId, isPublished) => {
        try {
            const response = await axios.put(`https://blogging-h2hl.onrender.com/api/v1/admin/blogs/${blogId}/status`, {
                isPublished
            }, {
                withCredentials: true
            });
            if (response.data.success) {
                toast.success(response.data.message);
                fetchBlogs(); // Refresh blogs list
            }
        } catch (error) {
            console.error('Error updating blog status:', error);
            toast.error('Failed to update blog status');
        }
    };

    // Delete blog
    const deleteBlog = async (blogId) => {
        if (!confirm('Are you sure you want to delete this blog? This action cannot be undone.')) {
            return;
        }
        try {
            const response = await axios.delete(`https://blogging-h2hl.onrender.com/api/v1/admin/blogs/${blogId}`, {
                withCredentials: true
            });
            if (response.data.success) {
                toast.success('Blog deleted successfully');
                fetchBlogs(); // Refresh blogs list
            }
        } catch (error) {
            console.error('Error deleting blog:', error);
            toast.error('Failed to delete blog');
        }
    };

    useEffect(() => {
        const loadDashboard = async () => {
            setLoading(true);
            try {
                console.log('Loading admin dashboard...');
                await Promise.all([fetchStats(), fetchUsers(), fetchBlogs()]);
                console.log('Dashboard loaded successfully');
            } catch (error) {
                console.error('Error loading dashboard:', error);
            } finally {
                setLoading(false);
            }
        };
        loadDashboard();
    }, []);

    if (loading) {
        return (
            <div className="flex items-center justify-center h-screen">
                <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-gray-900"></div>
            </div>
        );
    }

    return (
        <div className="pb-10 px-3 pt-20 md:ml-[320px]">
            <div className="max-w-6xl mx-auto mt-8">
                <h1 className="text-4xl font-bold mb-8">Admin Dashboard</h1>

                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    <Card className="bg-white dark:bg-gray-800">
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                            <Users className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                                                                            <CardContent>
                            <div className="text-2xl font-bold">{stats.totalUsers || 0}</div>
                            <p className="text-xs text-muted-foreground">
                                +{stats.recentUsers || 0} from last 7 days
                            </p>
                        </CardContent>
                    </Card>

                    <Card className="bg-white dark:bg-gray-800">
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Total Blogs</CardTitle>
                            <FileText className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">{stats.totalBlogs || 0}</div>
                            <p className="text-xs text-muted-foreground">
                                {stats.publishedBlogs || 0} published
                            </p>
                        </CardContent>
                    </Card>

                    <Card className="bg-white dark:bg-gray-800">
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Total Comments</CardTitle>
                            <MessageSquare className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">{stats.totalComments || 0}</div>
                            <p className="text-xs text-muted-foreground">
                                Across all blogs
                            </p>
                        </CardContent>
                    </Card>

                    <Card className="bg-white dark:bg-gray-800">
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Newsletter Subscribers</CardTitle>
                            <TrendingUp className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">{stats.totalSubscribers || 0}</div>
                            <p className="text-xs text-muted-foreground">
                                +{stats.recentSubscribers || 0} this week
                            </p>
                        </CardContent>
                    </Card>
                </div>

                {/* Tabs for Users and Blogs */}
                <Tabs defaultValue="users" className="space-y-4">
                    <TabsList className="grid w-full grid-cols-2">
                        <TabsTrigger value="users">Users Management</TabsTrigger>
                        <TabsTrigger value="blogs">Blogs Management</TabsTrigger>
                    </TabsList>

                    <TabsContent value="users" className="space-y-4">
                        <Card className="bg-white dark:bg-gray-800">
                            <CardHeader>
                                <CardTitle>Users Management</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <Table>
                                    <TableHeader>
                                        <TableRow className="border-b border-gray-200 dark:border-gray-700">
                                            <TableHead className="font-semibold">Name</TableHead>
                                            <TableHead className="font-semibold">Email</TableHead>
                                            <TableHead className="font-semibold">Role</TableHead>
                                            <TableHead className="font-semibold">Status</TableHead>
                                            <TableHead className="font-semibold">Joined</TableHead>
                                            <TableHead className="font-semibold">Actions</TableHead>
                                        </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        {users.length === 0 ? (
                                            <TableRow>
                                                <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                                                    No users found
                                                </TableCell>
                                            </TableRow>
                                        ) : (
                                            users.map((user) => (
                                                <TableRow key={user._id} className="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700">
                                                    <TableCell>
                                                        <div className="flex items-center space-x-2">
                                                            <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
                                                                {user.photoUrl ? (
                                                                    <img src={user.photoUrl} alt={user.firstName} className="w-8 h-8 rounded-full" />
                                                                ) : (
                                                                    <span className="text-sm font-medium">
                                                                        {user.firstName?.charAt(0)}{user.lastName?.charAt(0)}
                                                                    </span>
                                                                )}
                                                            </div>
                                                            <div>
                                                                <div className="font-medium">{user.firstName} {user.lastName}</div>
                                                            </div>
                                                        </div>
                                                    </TableCell>
                                                    <TableCell>{user.email}</TableCell>
                                                    <TableCell>
                                                        <Badge variant={user.role === 'admin' ? 'default' : 'secondary'}>
                                                            {user.role}
                                                        </Badge>
                                                    </TableCell>
                                                    <TableCell>
                                                        <Badge variant={user.isBlocked ? 'destructive' : 'default'}>
                                                            {user.isBlocked ? 'Blocked' : 'Active'}
                                                        </Badge>
                                                    </TableCell>
                                                    <TableCell>
                                                        {new Date(user.createdAt).toLocaleDateString()}
                                                    </TableCell>
                                                    <TableCell>
                                                        <div className="flex space-x-2">
                                                            <Dialog>
                                                                <DialogTrigger asChild>
                                                                    <Button variant="outline" size="sm">
                                                                        <Edit className="h-4 w-4" />
                                                                    </Button>
                                                                </DialogTrigger>
                                                                <DialogContent>
                                                                    <DialogHeader>
                                                                        <DialogTitle>Edit User Role</DialogTitle>
                                                                    </DialogHeader>
                                                                    <div className="space-y-4">
                                                                        <div>
                                                                            <Label>Current Role: {user.role}</Label>
                                                                        </div>
                                                                        <div>
                                                                            <Label>New Role</Label>
                                                                            <Select onValueChange={(value) => updateUserRole(user._id, value)}>
                                                                                <SelectTrigger>
                                                                                    <SelectValue placeholder="Select role" />
                                                                                </SelectTrigger>
                                                                                <SelectContent>
                                                                                    <SelectItem value="user">User</SelectItem>
                                                                                    <SelectItem value="admin">Admin</SelectItem>
                                                                                </SelectContent>
                                                                            </Select>
                                                                        </div>
                                                                    </div>
                                                                </DialogContent>
                                                            </Dialog>
                                                            <Button 
                                                                variant={user.isBlocked ? "default" : "destructive"}
                                                                size="sm"
                                                                onClick={() => toggleUserBlock(user._id)}
                                                            >
                                                                {user.isBlocked ? '🔓 Unblock' : '🚫 Block'}
                                                            </Button>
                                                            <Button 
                                                                variant="destructive" 
                                                                size="sm"
                                                                onClick={() => deleteUser(user._id)}
                                                            >
                                                                <Trash2 className="h-4 w-4" />
                                                            </Button>
                                                        </div>
                                                    </TableCell>
                                                </TableRow>
                                            ))
                                        )}
                                    </TableBody>
                                </Table>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="blogs" className="space-y-4">
                        <Card className="bg-white dark:bg-gray-800">
                            <CardHeader>
                                <CardTitle>Blogs Management</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <Table>
                                    <TableHeader>
                                        <TableRow className="border-b border-gray-200 dark:border-gray-700">
                                            <TableHead className="font-semibold">Title</TableHead>
                                            <TableHead className="font-semibold">Author</TableHead>
                                            <TableHead className="font-semibold">Category</TableHead>
                                            <TableHead className="font-semibold">Status</TableHead>
                                            <TableHead className="font-semibold">Created</TableHead>
                                            <TableHead className="font-semibold">Actions</TableHead>
                                        </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        {blogs.length === 0 ? (
                                            <TableRow>
                                                <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                                                    No blogs found
                                                </TableCell>
                                            </TableRow>
                                        ) : (
                                            blogs.map((blog) => (
                                                <TableRow key={blog._id} className="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700">
                                                    <TableCell>
                                                        <div className="font-medium">{blog.title}</div>
                                                        {blog.subtitle && (
                                                            <div className="text-sm text-muted-foreground">{blog.subtitle}</div>
                                                        )}
                                                    </TableCell>
                                                    <TableCell>
                                                        {blog.author ? `${blog.author.firstName} ${blog.author.lastName}` : 'Unknown'}
                                                    </TableCell>
                                                    <TableCell>
                                                        <Badge variant="outline">{blog.category}</Badge>
                                                    </TableCell>
                                                    <TableCell>
                                                        <Badge variant={blog.isPublished ? 'default' : 'secondary'}>
                                                            {blog.isPublished ? 'Published' : 'Draft'}
                                                        </Badge>
                                                    </TableCell>
                                                    <TableCell>
                                                        {new Date(blog.createdAt).toLocaleDateString()}
                                                    </TableCell>
                                                    <TableCell>
                                                        <div className="flex space-x-2">
                                                            <Button 
                                                                variant={blog.isPublished ? "outline" : "default"}
                                                                size="sm"
                                                                onClick={() => updateBlogStatus(blog._id, !blog.isPublished)}
                                                            >
                                                                {blog.isPublished ? <UserX className="h-4 w-4" /> : <UserCheck className="h-4 w-4" />}
                                                                {blog.isPublished ? 'Unpublish' : 'Publish'}
                                                            </Button>
                                                            <Button 
                                                                variant="destructive" 
                                                                size="sm"
                                                                onClick={() => deleteBlog(blog._id)}
                                                            >
                                                                <Trash2 className="h-4 w-4" />
                                                            </Button>
                                                        </div>
                                                    </TableCell>
                                                </TableRow>
                                            ))
                                        )}
                                    </TableBody>
                                </Table>
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
};

export default AdminDashboard; 